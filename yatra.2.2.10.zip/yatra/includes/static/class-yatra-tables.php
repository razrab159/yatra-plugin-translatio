<?php
defined('ABSPATH') || exit;

class Yatra_Tables
{
    const TOUR_DATES = 'tour_dates';

    const TOUR_ENQUIRIES = 'tour_enquiries';

    const TOUR_BOOKING_STATS = 'tour_booking_stats';

    const LOGS = 'logs';
}