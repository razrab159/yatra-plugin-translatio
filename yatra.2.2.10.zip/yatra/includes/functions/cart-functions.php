<?php
if (!function_exists('yatra_mini_cart')) {

    function yatra_mini_cart()
    {
        echo do_shortcode('[yatra_mini_cart]');
    }

}