<div class="yatra-field-wrap ">
    <label style="display: block;">&nbsp;&nbsp;</label>
    <button class="button-primary" id="yatra_add_new_pricing_option" name="yatra_add_new_pricing_option" type="button"
            value="<?php echo __('Add new pricing option', 'yatra') ?>">
        <i class="dashicons dashicons-insert"></i>
        <strong><?php echo esc_html(__('Add new pricing option', 'yatra')) ?></strong>

    </button>
</div>