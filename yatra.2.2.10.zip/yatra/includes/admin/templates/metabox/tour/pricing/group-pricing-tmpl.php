<script type="text/html" id="yatra-group-pricing-tmpl">
    <?php
    require_once "group-pricing.php";
    ?>
</script>