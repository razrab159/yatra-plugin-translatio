<table>
    <thead>
    <th><?php echo __('Label', 'yatra') ?></th>
    <th><?php echo __('Regular Price', 'yatra') ?></th>
    <th><?php echo __('Sales Price', 'yatra') ?></th>
    <th><?php echo __('Person', 'yatra') ?></th>
    <th><?php echo __('Price Per', 'yatra') ?></th>
    <th><?php echo __('Group Size', 'yatra') ?></th>
    </thead>
    <tbody>