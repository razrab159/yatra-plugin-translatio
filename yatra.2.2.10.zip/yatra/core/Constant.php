<?php

namespace Yatra\Core;

class Constant
{
    const TOUR_POST_TYPE = 'tour';

    const BOOKING_POST_TYPE = 'yatra-booking';

    const PAYMENT_POST_TYPE = 'yatra-payment';
}
