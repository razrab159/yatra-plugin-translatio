<?php

use Yatra\Core\Tour\RegularTour;
use Yatra\Core\Tour\ExternalTour;

/**
 * @global RegularTour|ExternalTour $yatra_tour
 * @since 2.1.12
 */
global $yatra_tour;